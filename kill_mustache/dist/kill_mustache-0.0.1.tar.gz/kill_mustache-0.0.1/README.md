kill_mustache
===============================

version number: 0.0.1
author: kill_mustache

Overview
--------

remove to mustache file

Installation / Usage
--------------------

To install use pip:

    $ pip install kill_mustache


Or clone the repo:

    $ git clone https://github.com/Vinicius-rodrigues/kill_mustache.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD